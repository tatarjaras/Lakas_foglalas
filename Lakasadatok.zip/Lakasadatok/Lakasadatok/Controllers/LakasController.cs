﻿using Lakasadatok.Data;
using Lakasadatok.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Lakasadatok.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class LakasController : ControllerBase
    {
        private readonly AppDbContext _context;

        public LakasController(AppDbContext context)
        {
            _context = context;
        }

        // GET: api/lakasok
        [HttpGet]
        public async Task<IActionResult> GetLakasok()
        {
            var lakasok = await _context.Lakasok.ToListAsync();
            return Ok(lakasok);
        }

        // GET: api/lakasok/{id}
        [HttpGet("{id}")]
        public async Task<IActionResult> GetLakas(int id)
        {
            var lakas = await _context.Lakasok.FindAsync(id);
            if (lakas == null)
            {
                return NotFound();
            }
            return Ok(lakas);
        }

        // POST: api/lakasok
        [HttpPost]
        public async Task<IActionResult> CreateLakas([FromBody] Lakas newLakas)
        {
            _context.Lakasok.Add(newLakas);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(GetLakas), new { id = newLakas.ID }, newLakas);
        }

        // PUT: api/lakasok/{id}
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateLakas(int id, [FromBody] Lakas updatedLakas)
        {
            var lakas = await _context.Lakasok.FindAsync(id);
            if (lakas == null)
            {
                return NotFound();
            }

            lakas.Cim = updatedLakas.Cim;
            lakas.Leiras = updatedLakas.Leiras;
            lakas.Ar = updatedLakas.Ar;

            await _context.SaveChangesAsync();
            return NoContent();
        }

        // DELETE: api/lakasok/{id}
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteLakas(int id)
        {
            var lakas = await _context.Lakasok.FindAsync(id);
            if (lakas == null)
            {
                return NotFound();
            }

            _context.Lakasok.Remove(lakas);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}
