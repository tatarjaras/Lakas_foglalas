﻿using Lakasadatok.Models;
using Microsoft.EntityFrameworkCore;

namespace Lakasadatok.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        // Táblák definíciója
        public DbSet<Felhasznalo> Felhasznalok { get; set; }
        public DbSet<Lakas> Lakasok { get; set; }
    }
}