﻿namespace Lakasadatok.Models
{
    public class Lakas
    {
        public int ID { get; set; }
        public string Cim { get; set; }
        public string Leiras { get; set; }
        public int Ar { get; set; }
    }
}