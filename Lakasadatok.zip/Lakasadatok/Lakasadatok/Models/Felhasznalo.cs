﻿namespace Lakasadatok.Models
{
    public class Felhasznalo
    {
        public int ID { get; set; }
        public string Nev { get; set; }
        public string Email { get; set; }
    }
}
