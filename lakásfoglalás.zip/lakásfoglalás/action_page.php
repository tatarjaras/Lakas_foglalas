<?php
$servername = "localhost";
$username = "root"; // a saját felhasználóneved
$password = ""; // a saját jelszavad
$dbname = "Lakásfoglalás"; // az adatbázis neve

// Kapcsolódás az adatbázishoz
$conn = new mysqli($servername, $username, $password, $dbname);

// Ellenőrzés, hogy sikerült-e a kapcsolat
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Adatok feldolgozása a formból
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['psw']; // Fontos: a jelszót titkosítani kell (pl. hash-elni) a valós alkalmazásokban!

    // Adat beszúrása az adatbázisba
    $sql = "INSERT INTO foglalas (email, password) VALUES ('$email', '$password')";

    if ($conn->query($sql) === TRUE) {
        echo "Foglalás sikeresen elmentve!";
    } else {
        echo "Hiba: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>
